const data = [
  {
    id: 1,
    name: "espresso",
    price: 2,
    image:
      "https://images.unsplash.com/photo-1553742198-6eea5ac42a24?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&h=480&ixid=MnwxfDB8MXxyYW5kb218MHx8ZXNwcmVzc298fHx8fHwxNjM0Nzk5ODIx&ixlib=rb-1.2.1&q=80&utm_campaign=api-credit&utm_medium=referral&utm_source=unsplash_source&w=480"
  },
  {
    id: 2,
    name: "v60",
    price: 2.5,
    image:
      "https://images.unsplash.com/photo-1560704429-509cb85baeb2?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&h=480&ixid=MnwxfDB8MXxyYW5kb218MHx8djYwfHx8fHx8MTYzNDc5OTkyOA&ixlib=rb-1.2.1&q=80&utm_campaign=api-credit&utm_medium=referral&utm_source=unsplash_source&w=480"
  },
  {
    id: 3,
    name: "chemex",
    price: 3,
    image:
      "https://images.unsplash.com/photo-1547838648-143047c05adf?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&h=480&ixid=MnwxfDB8MXxyYW5kb218MHx8Y2hlbWV4fHx8fHx8MTYzNDgwMDA2Mg&ixlib=rb-1.2.1&q=80&utm_campaign=api-credit&utm_medium=referral&utm_source=unsplash_source&w=480"
  },
  {
    id: 4,
    name: "cafe latte",
    price: 4,
    image:
      "https://images.unsplash.com/photo-1582202737800-8ab9a8cc6e6a?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&h=480&ixid=MnwxfDB8MXxyYW5kb218MHx8bGF0dGV8fHx8fHwxNjM0ODAwMTkx&ixlib=rb-1.2.1&q=80&utm_campaign=api-credit&utm_medium=referral&utm_source=unsplash_source&w=480"
  },
  {
    id: 5,
    name: "ice latte",
    price: 4.5,
    image:
      "https://images.unsplash.com/photo-1625021658694-dcbfc4d0fc33?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&h=480&ixid=MnwxfDB8MXxyYW5kb218MHx8aWNlIGxhdHRlfHx8fHx8MTYzNDgwMDI1NA&ixlib=rb-1.2.1&q=80&utm_campaign=api-credit&utm_medium=referral&utm_source=unsplash_source&w=480"
  },
  {
    id: 6,
    name: "affogato",
    price: 6,
    image:
      "https://images.unsplash.com/photo-1634487359881-e85815774c5f?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&h=480&ixid=MnwxfDB8MXxyYW5kb218MHx8YWZmb2dhdG98fHx8fHwxNjM0ODA0MDQw&ixlib=rb-1.2.1&q=80&utm_campaign=api-credit&utm_medium=referral&utm_source=unsplash_source&w=480"
  }
];

export default data;
